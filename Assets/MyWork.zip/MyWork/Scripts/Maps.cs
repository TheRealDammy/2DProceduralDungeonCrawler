using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Maps : MonoBehaviour
{
    [Header("Map Settings")]
    public int width = 50;
    public int height = 50;
    public float scale = 12f;

    [Header("Randomness")]
    public bool randomizeEachRun = true;
    public Vector2 baseOffset;
    public float offsetJitter = 9999f;

    [Header("Noise Settings")]
    public Wave[] heightWaves;
    public Wave[] moistureWaves;
    public Wave[] heatWaves;

    float[,] heightMap;
    float[,] moistureMap;
    float[,] heatMap;

    [Header("Biomes")]
    public BiomePresets[] biomes;

    [Header("Tilemaps")]
    public Tilemap groundTilemap;
    public Tilemap pathTilemap;
    public Tilemap wallTilemap;
    public Tilemap propBackTilemap;
    public Tilemap propFrontTilemap;

    [Header("Base Tiles")]
    public TileBase waterTile;
    public TileBase sandTile;

    [Header("Paths")]
    public PathPreset pathPreset;

    [Header("Walls")]
    public TileBase borderWallTile; // simple border wall tile

    [Header("Props")]
    public PropPreset[] props;

    [Header("Player Spawn")]
    public Transform player;
    public int spawnAttempts = 500;

    // thresholds
    [Header("Thresholds")]
    [Range(0f, 1f)] public float waterHeight = 0.10f;
    [Range(0f, 1f)] public float sandHeight = 0.15f;

    // internal
    HashSet<Vector3Int> pathCells = new HashSet<Vector3Int>();

    void Start()
    {
        GenerateMap();
    }

    public void GenerateMap()
    {
        ClearMaps();

        Vector2 offset = baseOffset;
        if (randomizeEachRun)
        {
            offset += new Vector2(Random.Range(-offsetJitter, offsetJitter),
                                  Random.Range(-offsetJitter, offsetJitter));
        }

        GenerateNoiseMaps(offset);
        GenerateBaseTerrain();
        GenerateBorderWalls();

        GeneratePaths();
        GenerateProps();

        SpawnPlayerRandom();
    }

    void ClearMaps()
    {
        groundTilemap.ClearAllTiles();
        pathTilemap.ClearAllTiles();
        wallTilemap.ClearAllTiles();
        propBackTilemap.ClearAllTiles();
        propFrontTilemap.ClearAllTiles();

        pathCells.Clear();
    }

    void GenerateNoiseMaps(Vector2 offset)
    {
        heightMap = NoiseGenerator.Generate(width, height, heightWaves, scale, offset);
        moistureMap = NoiseGenerator.Generate(width, height, moistureWaves, scale, offset);
        heatMap = NoiseGenerator.Generate(width, height, heatWaves, scale, offset);
    }

    void GenerateBaseTerrain()
    {
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                float h = heightMap[x, y];
                Vector3Int pos = new Vector3Int(x, y, 0);

                if (h < waterHeight)
                {
                    groundTilemap.SetTile(pos, waterTile);
                    continue;
                }

                if (h < sandHeight)
                {
                    groundTilemap.SetTile(pos, sandTile);
                    continue;
                }

                BiomePresets biome = GetBiome(h, moistureMap[x, y], heatMap[x, y]);
                TileBase t = biome.GetRandomTile();

                groundTilemap.SetTile(pos, t);

                // tint per cell (must clear flags first)
                groundTilemap.SetTileFlags(pos, TileFlags.None);
                groundTilemap.SetColor(pos, biome.tint);
            }
        }
    }

    void GenerateBorderWalls()
    {
        // Top & Bottom
        for (int x = 0; x < width; x++)
        {
            wallTilemap.SetTile(new Vector3Int(x, 0, 0), borderWallTile);
            wallTilemap.SetTile(new Vector3Int(x, height - 1, 0), borderWallTile);
        }

        // Left & Right
        for (int y = 0; y < height; y++)
        {
            wallTilemap.SetTile(new Vector3Int(0, y, 0), borderWallTile);
            wallTilemap.SetTile(new Vector3Int(width - 1, y, 0), borderWallTile);
        }
    }

    // --- PATHS ---

    void GeneratePaths()
    {
        // Example: connect a few random landmarks (inside borders)
        List<Vector2Int> landmarks = GenerateLandmarks(5);

        for (int i = 0; i < landmarks.Count - 1; i++)
            GeneratePath(landmarks[i], landmarks[i + 1]);

        ResolveAllPaths();
    }

    List<Vector2Int> GenerateLandmarks(int count)
    {
        var points = new List<Vector2Int>();

        int tries = 0;
        while (points.Count < count && tries < count * 50)
        {
            tries++;

            int x = Random.Range(2, width - 2);
            int y = Random.Range(2, height - 2);

            if (heightMap[x, y] < sandHeight) continue; // avoid water/sand
            if (wallTilemap.GetTile(new Vector3Int(x, y, 0)) != null) continue;

            points.Add(new Vector2Int(x, y));
        }

        // fallback: at least one
        if (points.Count == 0)
            points.Add(new Vector2Int(width / 2, height / 2));

        return points;
    }

    void GeneratePath(Vector2Int start, Vector2Int end)
    {
        Vector2Int current = start;

        int safety = width * height * 2;
        while (current != end && safety-- > 0)
        {
            Vector3Int cell = new Vector3Int(current.x, current.y, 0);

            // never put path on border walls
            if (wallTilemap.GetTile(cell) == null)
                pathCells.Add(cell);

            if (Random.value > 0.5f)
                current.x += Mathf.Clamp(end.x - current.x, -1, 1);
            else
                current.y += Mathf.Clamp(end.y - current.y, -1, 1);
        }

        var endCell = new Vector3Int(end.x, end.y, 0);
        if (wallTilemap.GetTile(endCell) == null)
            pathCells.Add(endCell);
    }

    void ResolveAllPaths()
    {
        foreach (Vector3Int pos in pathCells)
            ResolvePathTile(pos);
    }

    bool IsPath(Vector3Int pos) => pathCells.Contains(pos);

    void ResolvePathTile(Vector3Int pos)
    {
        if (wallTilemap.GetTile(pos) != null) return; // safety

        bool up = IsPath(pos + Vector3Int.up);
        bool down = IsPath(pos + Vector3Int.down);
        bool left = IsPath(pos + Vector3Int.left);
        bool right = IsPath(pos + Vector3Int.right);

        int connections = (up ? 1 : 0) + (down ? 1 : 0) + (left ? 1 : 0) + (right ? 1 : 0);

        TileBase tile;

        if (connections == 4) tile = pathPreset.cross;
        else if (connections == 3)
        {
            if (!up) tile = pathPreset.tDown;
            else if (!down) tile = pathPreset.tUp;
            else if (!left) tile = pathPreset.tRight;
            else tile = pathPreset.tLeft;
        }
        else if (connections == 2)
        {
            if (up && down) tile = pathPreset.straightVertical;
            else if (left && right) tile = pathPreset.straightHorizontal;
            else if (up && right) tile = pathPreset.cornerBL;
            else if (up && left) tile = pathPreset.cornerBR;
            else if (down && right) tile = pathPreset.cornerTL;
            else tile = pathPreset.cornerTR;
        }
        else
        {
            // single stub: choose based on which neighbour exists
            if (up || down) tile = pathPreset.straightVertical;
            else tile = pathPreset.straightHorizontal;
        }

        pathTilemap.SetTile(pos, tile);
    }

    // --- PROPS ---

    bool IsWater(Vector3Int pos)
    {
        return groundTilemap.GetTile(pos) == waterTile || groundTilemap.GetTile(pos) == sandTile;
        // If you have pond water using waterTile, this already blocks it.
        // If sand is walkable, remove "|| sandTile".
    }

    bool IsBlocked(Vector3Int pos)
    {
        return wallTilemap.GetTile(pos) != null;
    }

    bool IsPaths(Vector3Int pos)
    {
        return pathTilemap.GetTile(pos) != null;
    }

    bool IsOccupiedByProp(Vector3Int pos)
    {
        return propFrontTilemap.GetTile(pos) || propBackTilemap.GetTile(pos) != null;
    }

    bool CanPlaceProp(Vector3Int pos)
    {
        if (IsWater(pos)) return false;
        if (IsBlocked(pos)) return false;
        if (IsPaths(pos)) return false;
        if (IsOccupiedByProp(pos)) return false;
        return true;
    }

    bool CellOccupied(Vector3Int pos)
    {
        return propBackTilemap.GetTile(pos) != null || propFrontTilemap.GetTile(pos) != null;
    }

    void GenerateProps()
    {
        for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                Vector3Int pos = new Vector3Int(x, y, 0);

                if (!CanPlaceProp(pos))
                    continue;

                foreach (PropPreset prop in props)
                {
                    if (!prop.Matches(heightMap[x, y], moistureMap[x, y], heatMap[x, y]))
                        continue;

                    if (Random.value < prop.spawnChance)
                    {
                        Tilemap tm = prop.isTall ? propFrontTilemap : propBackTilemap;
                        tm.SetTile(pos, prop.GetRandomTile());
                        break; // one prop per cell
                    }
                }
            }
        }
    }

    // --- PLAYER SPAWN ---
    bool CanSpawnAt(Vector3Int pos)
    {
        // must be inside bounds (extra safety)
        if (pos.x <= 0 || pos.y <= 0 || pos.x >= width - 1 || pos.y >= height - 1)
            return false;

        // no water / ponds
        if (groundTilemap.GetTile(pos) == waterTile)
            return false;

        // no walls
        if (wallTilemap.GetTile(pos) != null)
            return false;

        // no paths
        if (pathTilemap != null && pathTilemap.GetTile(pos) != null)
            return false;

        // no props
        if (propBackTilemap.GetTile(pos) != null ||
            propFrontTilemap.GetTile(pos) != null)
            return false;

        return true;
    }

    void SpawnPlayerRandom()
    {
        if (player == null) return;

        for (int i = 0; i < spawnAttempts; i++)
        {
            int x = Random.Range(1, width - 1);
            int y = Random.Range(1, height - 1);

            Vector3Int cell = new Vector3Int(x, y, 0);

            if (!CanSpawnAt(cell))
                continue;

            player.position = groundTilemap.GetCellCenterWorld(cell);
            return;
        }

        // Fallback (guaranteed safe centre-ish)
        Vector3Int fallback = new Vector3Int(width / 2, height / 2, 0);
        player.position = groundTilemap.GetCellCenterWorld(fallback);
    }

    // --- BIOMES ---

    BiomePresets GetBiome(float height, float moisture, float heat)
    {
        BiomePresets bestBiome = null;
        float bestScore = float.MaxValue;

        foreach (BiomePresets biome in biomes)
        {
            if (!biome.Matches(height, moisture, heat))
                continue;

            float score =
                Mathf.Abs(height - biome.minHeight) +
                Mathf.Abs(moisture - biome.minMoisture) +
                Mathf.Abs(heat - biome.minHeat);

            if (score < bestScore)
            {
                bestScore = score;
                bestBiome = biome;
            }
        }

        return bestBiome ?? biomes[0];
    }
}
